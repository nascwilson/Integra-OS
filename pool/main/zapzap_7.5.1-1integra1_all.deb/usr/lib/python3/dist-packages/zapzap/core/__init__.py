"""Core infrastructure for ZapZap."""
