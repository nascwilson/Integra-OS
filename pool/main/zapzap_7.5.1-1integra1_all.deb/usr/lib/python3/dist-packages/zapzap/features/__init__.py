"""Application features for ZapZap."""
