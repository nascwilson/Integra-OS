"""Visual assets for ZapZap."""
