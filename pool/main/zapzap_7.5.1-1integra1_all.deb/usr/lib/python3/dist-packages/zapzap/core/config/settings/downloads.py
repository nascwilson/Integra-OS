"""Download behavior settings domain."""

from __future__ import annotations

import logging

from PyQt6.QtCore import QObject, pyqtSignal

from zapzap.core.config.settings.base import BaseSettings
from zapzap.core.config.settings_manager import SettingsManager


logger = logging.getLogger(__name__)


class DownloadBehavior:
    """Stable persisted identifiers for download handling."""

    DIALOG = "dialog"
    AUTOMATIC = "automatic"
    ASK_EVERY_TIME = "ask_every_time"

    VALUES = {DIALOG, AUTOMATIC, ASK_EVERY_TIME}


class PDFClickBehavior:
    """Preference for PDF navigation handled by Qt WebEngine."""

    PREVIEW = "preview"
    DOWNLOAD = "download"

    VALUES = {PREVIEW, DOWNLOAD}


class MultipleDownloadPermission:
    """Stable permission values for repeated WhatsApp downloads."""

    ASK = "ask"
    ALLOW = "allow"
    BLOCK = "block"

    VALUES = {ASK, ALLOW, BLOCK}


class DownloadSettingsEvents(QObject):
    """Notify live account contexts when temporary folders must be discarded."""

    clear_save_as_directories = pyqtSignal()
    pdf_click_behavior_changed = pyqtSignal()


download_settings_events = DownloadSettingsEvents()


class DownloadSettings(BaseSettings):
    """Semantic access to download behavior preferences."""

    _REMEMBER_SAVE_AS = ("downloads/remember_last_save_as_directory", True)
    _BEHAVIOR = ("downloads/behavior", DownloadBehavior.DIALOG)
    _AUTO_OPEN_MEDIA_LEGACY = ("downloads/auto_open_media", False)
    _AUTO_OPEN_PDF = ("downloads/auto_open_pdf", False)
    _PDF_CLICK_BEHAVIOR = ("downloads/pdf_click_behavior", PDFClickBehavior.PREVIEW)
    _AUTO_OPEN_IMAGES = ("downloads/auto_open_images", False)
    _MULTIPLE_DOWNLOAD_PERMISSION = (
        "downloads/whatsapp_multiple_download_permission",
        MultipleDownloadPermission.ASK,
    )

    @property
    def remember_last_save_as_directory(self) -> bool:
        return self._get_bool(self._REMEMBER_SAVE_AS)

    @remember_last_save_as_directory.setter
    def remember_last_save_as_directory(self, value: bool) -> None:
        self._set_bool(self._REMEMBER_SAVE_AS, value)
        if not value:
            download_settings_events.clear_save_as_directories.emit()

    @property
    def behavior(self) -> str:
        raw_value = self._get(self._BEHAVIOR)
        value = (
            raw_value
            if isinstance(raw_value, str)
            and raw_value in DownloadBehavior.VALUES
            else DownloadBehavior.DIALOG
        )
        if value != raw_value:
            logger.warning(
                "Invalid stored download behavior; replacing it with dialog"
            )
            self._set_str(self._BEHAVIOR, value)
        return value

    @behavior.setter
    def behavior(self, value: str) -> None:
        normalized = (
            value if value in DownloadBehavior.VALUES
            else DownloadBehavior.DIALOG
        )
        self._set_str(self._BEHAVIOR, normalized)

    @property
    def pdf_click_behavior(self) -> str:
        raw = self._get_str(self._PDF_CLICK_BEHAVIOR)
        if raw in PDFClickBehavior.VALUES:
            return raw
        self._set_str(self._PDF_CLICK_BEHAVIOR, PDFClickBehavior.PREVIEW)
        return PDFClickBehavior.PREVIEW

    @pdf_click_behavior.setter
    def pdf_click_behavior(self, value: str) -> None:
        normalized = (
            value if value in PDFClickBehavior.VALUES
            else PDFClickBehavior.PREVIEW
        )
        if self.pdf_click_behavior != normalized:
            self._set_str(self._PDF_CLICK_BEHAVIOR, normalized)
            download_settings_events.pdf_click_behavior_changed.emit()

    def _migrate_legacy_auto_open(self) -> None:
        legacy_key, _default = self._AUTO_OPEN_MEDIA_LEGACY
        if not SettingsManager.contains(legacy_key):
            return

        legacy_value = self._get_bool(self._AUTO_OPEN_MEDIA_LEGACY)
        pdf_key, _ = self._AUTO_OPEN_PDF
        images_key, _ = self._AUTO_OPEN_IMAGES

        if not SettingsManager.contains(pdf_key):
            self._set_bool(self._AUTO_OPEN_PDF, legacy_value)
        if not SettingsManager.contains(images_key):
            self._set_bool(self._AUTO_OPEN_IMAGES, legacy_value)

        SettingsManager.remove(legacy_key)

    @property
    def auto_open_pdf(self) -> bool:
        self._migrate_legacy_auto_open()
        return self._get_bool(self._AUTO_OPEN_PDF)

    @auto_open_pdf.setter
    def auto_open_pdf(self, value: bool) -> None:
        self._set_bool(self._AUTO_OPEN_PDF, value)

    @property
    def auto_open_images(self) -> bool:
        self._migrate_legacy_auto_open()
        return self._get_bool(self._AUTO_OPEN_IMAGES)

    @auto_open_images.setter
    def auto_open_images(self, value: bool) -> None:
        self._set_bool(self._AUTO_OPEN_IMAGES, value)

    @property
    def multiple_download_permission(self) -> str:
        raw_value = self._get_str(self._MULTIPLE_DOWNLOAD_PERMISSION)
        if raw_value in MultipleDownloadPermission.VALUES:
            return raw_value

        self._set_str(
            self._MULTIPLE_DOWNLOAD_PERMISSION,
            MultipleDownloadPermission.ASK,
        )
        return MultipleDownloadPermission.ASK

    @multiple_download_permission.setter
    def multiple_download_permission(self, permission: str) -> None:
        normalized = (
            permission
            if permission in MultipleDownloadPermission.VALUES
            else MultipleDownloadPermission.ASK
        )
        self._set_str(self._MULTIPLE_DOWNLOAD_PERMISSION, normalized)

    def clear_multiple_download_permission(self) -> None:
        self.multiple_download_permission = MultipleDownloadPermission.ASK
