"""Browser WebEngine integration."""
