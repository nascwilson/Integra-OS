"""Controller for the general settings page."""

from gettext import gettext as _

from PyQt6.QtCore import QLocale
from PyQt6.QtWidgets import QApplication

from zapzap.core.config.settings.downloads import DownloadBehavior, PDFClickBehavior
from zapzap.features.dictionaries.dictionary_manager import (
    open_dictionary_manager,
)
from zapzap.features.dictionaries.dictionaries_manager import DictionariesManager
from zapzap.features.dictionaries.spellcheck_language_picker import (
    open_spellcheck_language_picker,
)
from zapzap.features.settings.pages.language_downloads.model import LanguageDownloadSettingsModel
from zapzap.features.settings.pages.language_downloads.view import LanguageDownloadSettingsView


class LanguageDownloadSettingsController(LanguageDownloadSettingsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.model = LanguageDownloadSettingsModel()
        self._load_settings()
        self._connect_signals()

    def _load_settings(self):
        self.spellchecker_groupBox.checkbox.setChecked(
            self.model.spellcheck_enabled
        )

        self._update_spellcheck_language_summary()
        self.spellchecker_options_group.setEnabled(
            self.spellchecker_groupBox.checkbox.isChecked()
        )
        self.manage_dictionaries_row.setVisible(
            DictionariesManager.is_management_available()
        )

        self.download_path.setText(self.model.get_download_path())
        self._load_download_behavior_options()
        self._load_pdf_click_behavior_options()
        self.remember_save_as_row.checkbox.setChecked(
            self.model.remember_last_save_as_directory
        )
        self.auto_open_pdf_row.checkbox.setChecked(
            self.model.auto_open_pdf
        )
        self.auto_open_images_row.checkbox.setChecked(
            self.model.auto_open_images
        )

        self._load_interface_languages()

    def _connect_signals(self):
        self.spellchecker_groupBox.checkbox.toggled.connect(
            self._handle_toggled_spellcheck
        )
        self.interface_language_comboBox.currentIndexChanged.connect(
            self._handle_interface_language
        )
        self.interface_language_comboBox.activated.connect(
            self._handle_interface_language
        )
        self.btn_select_spell_languages.clicked.connect(
            self._open_spellcheck_language_picker
        )
        self.btn_manage_dictionaries.clicked.connect(
            self._open_dictionary_manager
        )
        self.btn_path_download.clicked.connect(self._handle_path_download)
        self.btn_restore_path_download.clicked.connect(
            self._handle_restore_path_download
        )
        self.download_behavior_combo.currentIndexChanged.connect(
            self._handle_download_behavior
        )
        self.pdf_click_behavior_combo.currentIndexChanged.connect(
            self._handle_pdf_click_behavior
        )
        self.remember_save_as_row.checkbox.toggled.connect(
            self._handle_remember_save_as
        )
        self.auto_open_pdf_row.checkbox.toggled.connect(
            self._handle_auto_open_pdf
        )
        self.auto_open_images_row.checkbox.toggled.connect(
            self._handle_auto_open_images
        )
        self.btn_reset_download_permissions.clicked.connect(
            self._handle_reset_download_permissions
        )

    def _load_download_behavior_options(self):
        combo = self.download_behavior_combo
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(
            _("Show download window"),
            DownloadBehavior.DIALOG,
        )
        combo.addItem(
            _("Save automatically to selected folder"),
            DownloadBehavior.AUTOMATIC,
        )
        combo.addItem(
            _("Ask where to save every time"),
            DownloadBehavior.ASK_EVERY_TIME,
        )
        index = combo.findData(self.model.download_behavior)
        combo.setCurrentIndex(max(0, index))
        combo.blockSignals(False)

    def _load_pdf_click_behavior_options(self):
        combo = self.pdf_click_behavior_combo
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(_("Preview in WhatsApp"), PDFClickBehavior.PREVIEW)
        combo.addItem(_("Download directly (where supported)"), PDFClickBehavior.DOWNLOAD)
        combo.setCurrentIndex(max(0, combo.findData(self.model.pdf_click_behavior)))
        combo.blockSignals(False)

    def _load_interface_languages(self):
        combo = self.interface_language_comboBox
        combo.blockSignals(True)
        combo.clear()
        combo.addItem(_("System default"), "system")

        for language in self.model.list_available_languages():
            combo.addItem(self._language_label(language), language)

        current_language = self.model.get_current_language()
        index = combo.findData(current_language)
        if index < 0:
            index = 0
        combo.setCurrentIndex(index)
        combo.updateGeometry()
        combo.blockSignals(False)

    def _language_label(self, language):
        locale = QLocale(language)
        language_name = QLocale.languageToString(locale.language())
        territory_name = QLocale.territoryToString(locale.territory())

        if territory_name:
            return f"{language_name} ({territory_name}) - {language}"
        return f"{language_name} - {language}"

    def _handle_interface_language(self, *_args):
        language = self.interface_language_comboBox.currentData()
        self.model.set_current_language(language)
        self.model.apply_translation()
        self._retranslate_application()

    def _retranslate_application(self):
        app = QApplication.instance()
        for widget in app.allWidgets():
            self._call_retranslate(widget)

        if self._reload_open_settings_page(app):
            return

        self._load_interface_languages()

    @staticmethod
    def _reload_open_settings_page(app):
        window = getattr(app, "getWindow", lambda: None)()
        settings = getattr(window, "app_settings", None)
        if settings is None:
            return False

        page_id = settings.current_page_id
        window.close_settings()
        window.open_settings()

        next_settings = getattr(window, "app_settings", None)
        if next_settings is not None and page_id is not None:
            next_settings.open_page_id(page_id)
        return True

    @staticmethod
    def _call_retranslate(widget):
        for method_name in ("retranslate_ui", "retranslateUi"):
            retranslate = getattr(widget, method_name, None)
            if not callable(retranslate):
                continue
            try:
                retranslate()
            except TypeError:
                retranslate(widget)

    def _handle_toggled_spellcheck(self, toggled):
        setattr(self.model, "spellcheck_enabled", toggled)
        self.spellchecker_options_group.setEnabled(toggled)
        self._update_browser_spellcheck()

    def _update_spellcheck_language_summary(self):
        options = {
            option.code: option.label
            for option in self.model.list_dictionary_options()
        }
        selected = self.model.get_selected_dictionaries()
        if not selected:
            summary = _("No dictionary available")
        elif len(selected) == 1:
            summary = options.get(selected[0], selected[0])
        else:
            summary = _("{language} and {count} more").format(
                language=options.get(selected[0], selected[0]),
                count=len(selected) - 1,
            )
        self.spell_languages_row.description_label.setText(summary)
        self.btn_select_spell_languages.setEnabled(bool(options))
        self.btn_select_spell_languages.setAccessibleDescription(summary)

    def _open_spellcheck_language_picker(self):
        if open_spellcheck_language_picker(
            self,
            on_applied=self._on_spellcheck_languages_applied,
            on_manage=self.focus_spellchecker_management,
        ):
            self._update_spellcheck_language_summary()

    def _on_spellcheck_languages_applied(self):
        self._update_browser_spellcheck()
        self._update_spellcheck_language_summary()

    def focus_spellchecker_management(self):
        """Open the shared manager used by Settings and the picker."""
        self._open_dictionary_manager()

    def _open_dictionary_manager(self):
        open_dictionary_manager(
            self,
            on_changed=self._on_dictionaries_changed,
        )

    def _on_dictionaries_changed(self):
        self._update_browser_spellcheck()
        self._update_spellcheck_language_summary()

    def _handle_autostart(self):
        self.model.set_autostart(self.btn_start_system.isChecked())

    def _update_browser_spellcheck(self):
        QApplication.instance().getWindow().browser.update_spellcheck()

    def _handle_download_behavior(self, *_args):
        value = self.download_behavior_combo.currentData()
        self.model.download_behavior = value

    def _handle_pdf_click_behavior(self, *_args):
        self.model.pdf_click_behavior = self.pdf_click_behavior_combo.currentData()

    def _handle_remember_save_as(self, enabled):
        self.model.remember_last_save_as_directory = enabled

    def _handle_auto_open_pdf(self, enabled):
        self.model.auto_open_pdf = enabled

    def _handle_auto_open_images(self, enabled):
        self.model.auto_open_images = enabled

    def _handle_reset_download_permissions(self):
        self.model.clear_multiple_download_permissions()

    def _handle_path_download(self):
        new_path = self.model.open_folder_dialog(self)
        if new_path:
            self.model.set_download_path(new_path)
            self.download_path.setText(self.model.get_download_path())

    def _handle_restore_path_download(self):
        self.download_path.setText(self.model.restore_download_path())
