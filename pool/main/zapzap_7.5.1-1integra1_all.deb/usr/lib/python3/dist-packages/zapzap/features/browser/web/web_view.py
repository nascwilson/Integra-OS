import re
import shutil
import os
import logging
import json

from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings, QWebEnginePage, QWebEngineScript
from PyQt6.QtCore import QUrl, pyqtSignal, QTimer, QEvent, Qt, QFile, QTextStream, QObject, pyqtSlot, QRect
from PyQt6.QtWidgets import QApplication, QWidget
from PyQt6.QtGui import QAction

from zapzap.core.theme.theme_manager import ThemeManager
from zapzap.core.config.settings.appearance import AppearanceSettings
from zapzap.assets.icons.system_icon import SystemIcon
from zapzap.core.config.settings.downloads import (
    DownloadSettings, PDFClickBehavior, download_settings_events,
)
from zapzap.features.browser.web.page_controller import PageController
from zapzap.features.browser.web.popup_window import InternalWebPopup
from zapzap.features.accounts.domain.user import (
    MAX_ZOOM_FACTOR,
    MIN_ZOOM_FACTOR,
    User,
    apply_zoom_factor,
)
from zapzap import __user_agent__, __whatsapp_url__
from zapzap.features.notifications.notification_service import NotificationService
from zapzap.features.dictionaries.dictionaries_manager import DictionariesManager
from zapzap.features.dictionaries.spellcheck_language_picker import (
    open_spellcheck_language_picker,
)
from zapzap.features.downloads.download_manager import DownloadManager
from zapzap.features.browser.web.clipboard_table import calc_table_as_plain_text
from zapzap.core.config.settings_manager import SettingsManager
from zapzap.core.config.settings.system import SystemSettings
from zapzap.core.config.settings.performance import (
    PerformanceSettings,
    apply_http_cache_size,
    apply_http_cache_type,
    apply_persistent_cookies_policy,
)
from zapzap.core.diagnostics import crash_handler  # instância global
from zapzap.core.diagnostics.webengine_probe import diagnostic_mode, probe


_EVENT_MODE = diagnostic_mode()

from gettext import gettext as _


logger = logging.getLogger(__name__)


class WebView(QWebEngineView):
    integrated_selector_requested = pyqtSignal(object)
    update_button_signal = pyqtSignal(int, int)  # Sinal para atualizar botões

    QWEBENGINE_CACHE_TYPES = {
        "MemoryHttpCache": QWebEngineProfile.HttpCacheType.MemoryHttpCache,
        "DiskHttpCache": QWebEngineProfile.HttpCacheType.DiskHttpCache,
        "NoCache": QWebEngineProfile.HttpCacheType.NoCache
    }

    USER_AGENTS = {
        "Default": __user_agent__,
        "Windows Chrome": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Windows Firefox": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "Windows Edge": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
        "Mac Safari": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2.1 Safari/605.1.15",
        "Mac Chrome": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Linux Firefox": "Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "Linux Chrome": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    RESIZABLE_CHAT_LIST_SCRIPT_NAME = "zapzap_resizable_chat_list"

    def __init__(self, user: User = None, page_index=None, parent=None):
        super().__init__(parent)
        probe.watch(self, "view")
        self.user = user
        self.page_index = page_index
        self.profile = None  # Inicializa o perfil como None
        self._gesture_filter_installed = False
        self.whatsapp_page = None
        self._popup_windows = set()

        self._cache_path = None
        self._storage_path = None

        self.notifications = NotificationService()
        self._devtools_view = None
        self._devtools_page = None

        self._last_tmp_file = None
        self._shutting_down = False

        self._web_channel_bridge = None
        self._integrated_selector_enabled = AppearanceSettings().integrated_account_selector_enabled
        self._integrated_other_unread = False

        # In-memory only: last directory chosen with Save As for this
        # conversation. Never persisted.
        self.last_download_directory = None
        download_settings_events.clear_save_as_directories.connect(
            self.clear_download_directory
        )
        download_settings_events.pdf_click_behavior_changed.connect(
            self._apply_pdf_click_behavior
        )

        self._reload_timer = QTimer(self)
        self._reload_timer.setSingleShot(True)
        self._reload_timer.timeout.connect(self.load_page)

        self._render_crash_reload_timer = QTimer(self)
        self._render_crash_reload_timer.setSingleShot(True)
        self._render_crash_reload_timer.timeout.connect(self.load_page)
        probe.watch(self._reload_timer, "reload-timer", self)
        probe.watch(self._render_crash_reload_timer, "renderer-reload-timer", self)

        self._signals_configured = False

        if user.enable:
            self._initialize()

    def _save_zoom_factor(self):
        try:
            if self.user and not self.isHidden():
                self.user.zoomFactor = self.zoomFactor()
        except RuntimeError:
            pass

    def _initialize(self):
        """Configuração inicial."""
        self._configure_signals()
        self._configure_profile()

        self._setup_page()

        # Install one application-level filter for native gestures delivered
        # directly to the internal WebEngine render widget.
        if not self._gesture_filter_installed:
            QApplication.instance().installEventFilter(self)
            self._gesture_filter_installed = True

    def _configure_signals(self):
        """Configura os sinais para eventos."""
        if self._signals_configured:
            return
        self.titleChanged.connect(self._on_title_changed)
        self.loadFinished.connect(self._on_load_finished)
        ThemeManager.instance().theme_changed.connect(self.apply_theme)
        self._signals_configured = True

    def _configure_profile(self):
        """Configura o perfil do QWebEngine."""
        self.profile = QWebEngineProfile(str(self.user.id), self)
        probe.watch(self.profile, "profile", self)

        self._cache_path = self.profile.cachePath()
        self._storage_path = self.profile.persistentStoragePath()

        selected_ua_name = SettingsManager.get(
            f"{self.user.id}/user_agent", "Default")
        ua_string = self.USER_AGENTS.get(
            selected_ua_name, self.USER_AGENTS["Default"])
        self.profile.setHttpUserAgent(ua_string)

        self.profile.downloadRequested.connect(
            lambda download: DownloadManager.on_downloadRequested(
                download,
                self
            )
        )
        self.profile.setNotificationPresenter(
            lambda notification: self.notifications.notify(self, notification)
        )
        self.profile.settings().setAttribute(
            QWebEngineSettings.WebAttribute.ScrollAnimatorEnabled, SettingsManager.get("web/scroll_animator", False))
        self._apply_pdf_click_behavior()

        self.configure_spellcheck()

        apply_http_cache_size(
            self.profile,
            PerformanceSettings().cache_size_max,
        )
        performance_settings = PerformanceSettings()
        apply_http_cache_type(
            self.profile,
            performance_settings.cache_type,
            self.QWEBENGINE_CACHE_TYPES,
        )
        cookie_policies = {
            False: QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies,
            True: QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies,
        }
        apply_persistent_cookies_policy(
            self.profile,
            performance_settings.get_boolean_setting("persistent_cookies"),
            cookie_policies,
        )

        self._install_ctrl_arrow_visual_navigation_fix()

        # Instala o handler de crash específico para este WebView
        crash_handler.register_profile(self.profile)
        self._inject_webrtc_shield()

    def _apply_pdf_click_behavior(self):
        """Enable PDF plugin for previews or download PDF navigations."""
        if self.profile is None:
            return
        preview = DownloadSettings().pdf_click_behavior == PDFClickBehavior.PREVIEW
        settings = self.profile.settings()
        # Qt WebEngine needs PluginsEnabled as well as PdfViewerEnabled.
        settings.setAttribute(
            QWebEngineSettings.WebAttribute.PluginsEnabled, preview
        )
        pdf_viewer_attr = getattr(
            QWebEngineSettings.WebAttribute, "PdfViewerEnabled", None
        )
        if pdf_viewer_attr is not None:
            settings.setAttribute(pdf_viewer_attr, preview)
        if getattr(self, "whatsapp_page", None) is not None and not getattr(
            self, "_shutting_down", False
        ):
            # Browser settings do not control WhatsApp Web's own PDF overlay.
            mode = json.dumps(DownloadSettings().pdf_click_behavior)
            self.whatsapp_page.runJavaScript(
                "window.__zapzapPdfClicks?.setMode(" + mode + ")"
            )

    def _install_pdf_click_controller(self):
        """Install a document-click handler inside WhatsApp's page world."""
        try:
            path = os.path.join(
                os.path.dirname(__file__), "scripts", "pdf_click_controller.js"
            )
            with open(path, encoding="utf-8") as script_file:
                source = script_file.read()
            script = QWebEngineScript()
            script.setName("zapzap_pdf_click_controller")
            script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
            script.setRunsOnSubFrames(False)
            script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
            mode = json.dumps(DownloadSettings().pdf_click_behavior)
            script.setSourceCode(
                source.replace("__ZAPZAP_PDF_CLICK_MODE__", mode)
            )
            self.profile.scripts().insert(script)
        except Exception:
            logger.exception("Failed to install PDF document click handler")

    def _install_ctrl_arrow_visual_navigation_fix(self):
        if SettingsManager.get("web/ctrl_arrow_visual_navigation_fix", True):
            try:
                base_dir = os.path.dirname(__file__)
                js_path = os.path.join(
                    base_dir, "scripts", "ctrl_arrow_visual_navigation_fix.js")
                with open(js_path, "r", encoding="utf-8") as f:
                    js_code = f.read()

                script = QWebEngineScript()
                script.setName("ctrl_arrow_visual_navigation_fix")
                script.setInjectionPoint(
                    QWebEngineScript.InjectionPoint.DocumentCreation)
                script.setRunsOnSubFrames(True)
                script.setSourceCode(js_code)
                script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
                self.profile.scripts().insert(script)
            except Exception as e:
                print(f"Error injecting ctrl_arrow_visual_navigation_fix: {e}")

    def _inject_webrtc_shield(self):
        """Inject the legacy page-level WebRTC candidate obfuscation shim.

        Network isolation for explicit proxies is handled before WebEngine
        starts through Chromium's native IP handling policy.
        """
        if SettingsManager.get("privacy/webrtc_shield", False):
            try:
                base_dir = os.path.dirname(__file__)
                js_path = os.path.join(base_dir, "scripts", "webrtc_shield.js")
                with open(js_path, "r", encoding="utf-8") as f:
                    js_code = f.read()

                script = QWebEngineScript()
                script.setName("webrtc_shield")
                script.setInjectionPoint(
                    QWebEngineScript.InjectionPoint.DocumentCreation)
                script.setRunsOnSubFrames(True)
                script.setSourceCode(js_code)
                script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
                self.profile.scripts().insert(script)
            except Exception as e:
                print(f"Error injecting WebRTC shield: {e}")

    def _inject_web_theme_controller(self):
        """Injects the JavaScript code for the ZapZap WAWeb Theme Controller and QWebChannel support."""
        try:
            self._setup_web_channel()
            placeholders = {
                "{qwebchannel_js_code}": self._get_web_channel_js_code(),
                "{quick_accounts_visible}": json.dumps(self._integrated_selector_enabled),
                "{quick_accounts_icon}": SystemIcon.SVG_ICONS["view_grid"].format(fill_color="currentColor"),
                "{selector_label}": json.dumps(_("Account selector")),
                "{selector_activity_label}": json.dumps(_("Notifications")),
                "{current_color_scheme}": (
                    ThemeManager.get_current_color_scheme().name.lower()
                ),
            }
            base_dir = os.path.dirname(__file__)
            js_path = os.path.join(base_dir, "scripts", "theme_controller.js")
            file = QFile(js_path)
            if not file.open(QFile.OpenModeFlag.ReadOnly):
                raise RuntimeError(file.errorString())
            js_code = QTextStream(file).readAll()
            pattern = re.compile(
                "|".join(re.escape(key) for key in placeholders)
            )
            js_code = pattern.sub(lambda m: placeholders[m.group(0)], js_code)
            script = QWebEngineScript()
            script.setName("zapzap_web_theme_controller")
            script.setInjectionPoint(
                QWebEngineScript.InjectionPoint.DocumentReady)
            script.setRunsOnSubFrames(False)
            script.setSourceCode(js_code)
            script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
            self.profile.scripts().insert(script)
        except Exception:
            logger.exception(
                "Failed to install the web theme controller; using ForceDarkMode"
            )
            if self.whatsapp_page:
                try:
                    self.whatsapp_page.fall_back_to_force_dark_mode()
                except Exception:
                    logger.exception(
                        "Failed to activate the web theme fallback; continuing "
                        "with the page default"
                    )

    def _setup_web_channel(self) -> None:
        class ZapZapBridge(QObject):
            @pyqtSlot()
            def on_theme_controller_injection_success(self):
                self._webview.apply_theme(
                    ThemeManager.get_current_theme(),
                    ThemeManager.get_current_color_scheme()
                )

            @pyqtSlot(str, bool)
            def on_waweb_theme_changed(self, new_theme_value: str, system_theme_mode: bool):
                # Redundant protection against theme changes fired from the WhatsApp Web settings.
                # Force WAWeb to always use the theme from the ZapZap settings.
                self._webview.apply_theme(
                    ThemeManager.get_current_theme(),
                    ThemeManager.get_current_color_scheme()
                )

            @pyqtSlot(str)
            def on_theme_controller_failure(self, message: str):
                if self._webview.whatsapp_page:
                    self._webview.whatsapp_page.on_apply_theme_result(
                        False, message)
                    self._webview.whatsapp_page.fall_back_to_force_dark_mode()

            @pyqtSlot()
            def on_quick_accounts_controller_ready(self):
                self._webview._sync_integrated_selector()

            @pyqtSlot(int, int, int, int)
            def open_recent_accounts(self, x, y, width, height):
                view = self._webview
                if view._shutting_down or not view._integrated_selector_enabled:
                    return
                zoom = view.zoomFactor()
                local = QRect(round(x * zoom), round(y * zoom),
                              round(width * zoom), round(height * zoom)).intersected(view.rect())
                if not local.isEmpty():
                    view.integrated_selector_requested.emit(
                        QRect(view.mapToGlobal(local.topLeft()), local.size())
                    )

            def __init__(self, webview):
                super().__init__()
                self.web_channel = QWebChannel(self)
                self.web_channel.registerObject("zapZapBridge", self)
                self._webview = webview

        self._web_channel_bridge = ZapZapBridge(self)
        self.whatsapp_page.setWebChannel(
            self._web_channel_bridge.web_channel,
            QWebEngineScript.ScriptWorldId.MainWorld
        )

    def set_integrated_selector_state(self, enabled, has_other_unread):
        self._integrated_selector_enabled = bool(enabled)
        self._integrated_other_unread = bool(has_other_unread)
        self._sync_integrated_selector()

    def _sync_integrated_selector(self):
        if self.whatsapp_page is None or self._shutting_down:
            return
        state = json.dumps([self._integrated_selector_enabled, self._integrated_other_unread])
        self.whatsapp_page.runJavaScript(
            "window._zapZapQuickAccountsController && "
            f"window._zapZapQuickAccountsController.setState(...{state});"
        )

    def set_resizable_chat_list_enabled(self, enabled: bool) -> None:
        """Turn chat list resizing on or off in the loaded page and on reloads."""
        if self.profile is None or self.whatsapp_page is None or self._shutting_down:
            return
        enabled = bool(enabled)
        self._install_resizable_chat_list(enabled)
        if enabled:
            source = self._resizable_chat_list_source()
            if source:
                self.whatsapp_page.runJavaScript(source)
        else:
            self.whatsapp_page.runJavaScript(
                "window._zapZapResizableChatList && "
                "window._zapZapResizableChatList.destroy();"
            )

    def compact_chat_list(self) -> None:
        """Apply the minimum width using the native list resize controller."""
        if self.profile is None or self.whatsapp_page is None or self._shutting_down:
            return
        self.set_resizable_chat_list_enabled(True)
        self.whatsapp_page.runJavaScript(
            "window._zapZapResizableChatList && "
            "window._zapZapResizableChatList.compact();"
        )

    def _install_resizable_chat_list(self, enabled: bool) -> None:
        scripts = self.profile.scripts()
        for script in scripts.find(self.RESIZABLE_CHAT_LIST_SCRIPT_NAME):
            scripts.remove(script)
        if not enabled:
            return
        source = self._resizable_chat_list_source()
        if not source:
            return
        script = QWebEngineScript()
        script.setName(self.RESIZABLE_CHAT_LIST_SCRIPT_NAME)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
        script.setRunsOnSubFrames(False)
        script.setSourceCode(source)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        scripts.insert(script)

    @staticmethod
    def _resizable_chat_list_source() -> str:
        js_path = os.path.join(
            os.path.dirname(__file__), "scripts", "resizable_chat_list.js"
        )
        try:
            with open(js_path, "r", encoding="utf-8") as js_file:
                js_code = js_file.read()
        except OSError:
            logger.exception("Failed to read the resizable chat list script")
            return ""
        placeholders = {
            "{resize_handle_label}": json.dumps(_("Chat list width")),
            "{resize_handle_hint}": json.dumps(
                _("Drag or use the arrow keys to resize. Double-click or "
                  "press Enter to restore the default width.")
            ),
        }
        for placeholder, value in placeholders.items():
            js_code = js_code.replace(placeholder, value)
        return js_code

    @staticmethod
    def _get_web_channel_js_code() -> str:
        file = QFile(":/qtwebchannel/qwebchannel.js")
        if not file.open(QFile.OpenModeFlag.ReadOnly):
            raise RuntimeError(file.errorString())
        return QTextStream(file).readAll()

    def configure_spellcheck(self):
        """Configura o corretor ortográfico."""
        if self.user.enable:
            try:
                self.profile.setSpellCheckEnabled(
                    SettingsManager.get("system/spellCheckers", True)
                )
                self.profile.setSpellCheckLanguages(
                    DictionariesManager.get_selected_languages()
                )
            except Exception:
                logger.exception(
                    "Failed to apply spellcheck settings; disabling spellcheck"
                )
                try:
                    self.profile.setSpellCheckLanguages([])
                    self.profile.setSpellCheckEnabled(False)
                except Exception:
                    logger.exception(
                        "Failed to disable spellcheck; continuing with the "
                        "Qt profile default"
                    )

    def _setup_page(self):
        """Configura a página e carrega a URL inicial."""
        self.whatsapp_page = PageController(
            self.profile,
            popup_host=self,
            parent=self,
        )
        probe.watch(self.whatsapp_page, "page", self)
        self.whatsapp_page.user_id = self.user.id
        self.whatsapp_page.setAudioMuted(SystemSettings().audio_muted)
        self.whatsapp_page.renderProcessTerminated.connect(
            self._on_render_crash)
        self._inject_web_theme_controller()
        self._install_pdf_click_controller()
        self._install_resizable_chat_list(
            AppearanceSettings().resizable_chat_list_enabled
        )
        self.load_page()

    def _on_render_crash(self, terminationStatus, exitCode):
        with probe.scope("renderer_terminated", self, status=terminationStatus, exit_code=exitCode):
            if self._shutting_down or not self.user.enable or not self.whatsapp_page:
                return
            print(
                f"Tab renderer crashed (status={terminationStatus}, code={exitCode}). Reloading...")
            self._render_crash_reload_timer.start(1000)

    def contextMenuEvent(self, event):
        """Cria o menu de contexto personalizado ao clicar com o botão direito."""

        # Criação do menu de contexto padrão
        menu = self.createStandardContextMenu()

        # 1. Remoção de ações indesejadas
        actions_to_remove = [
            'Back', 'View page source', 'Save page', 'Forward',
            'Open link in new tab', 'Save link', 'Open link in new window',
            'Paste and match style', 'Reload', 'Copy image address'
        ]
        menu = self._remove_actions(menu, actions_to_remove)

        # 2. Aplicação de traduções às ações
        translations = {
            'Undo': _('Undo'), 'Redo': _('Redo'), 'Cut': _('Cut'),
            'Copy': _('Copy'), 'Paste': _('Paste'), 'Select all': _('Select all'),
            'Save image': _('Save image'), 'Copy image': _('Copy image'),
            'Copy link address': _('Copy link address')
        }
        self._translate_actions(menu, translations)

        # 3. Adiciona novo comportamento para "Copy link address"
        self._set_copy_link_behavior(menu)

        # 4. Configuração de correção ortográfica
        self._add_spellcheck_actions(menu)

        # Exibição do menu de contexto
        menu.exec(event.globalPos())

    # Métodos auxiliares
    def _remove_actions(self, menu, actions_to_remove):
        """Remove ações indesejadas do menu."""
        for action in menu.actions():
            if action.text() in actions_to_remove:
                menu.removeAction(action)
        return menu

    def _translate_actions(self, menu, translations):
        """Aplica traduções às ações do menu."""
        for action in menu.actions():
            if action.text() in translations:
                action.setText(translations[action.text()])

    def _set_copy_link_behavior(self, menu):
        """Define o comportamento personalizado para 'Copy link address'."""
        for action in menu.actions():
            if action.text() == _("Copy link address"):
                try:
                    action.triggered.disconnect()
                except TypeError:
                    pass  # Nenhum sinal estava conectado

                def setClipboard():
                    cb = QApplication.clipboard()
                    cb.clear(mode=cb.Mode.Clipboard)
                    cb.setText(self.whatsapp_page.link_context,
                               mode=cb.Mode.Clipboard)

                action.triggered.connect(setClipboard)

    def _add_spellcheck_actions(self, menu):
        """Adiciona opções de correção ortográfica e seleção de idiomas."""
        profile = self.page().profile()
        # Ação de correção ortográfica
        spellcheck_action = QAction(_("Check Spelling"), self)
        spellcheck_action.setCheckable(True)
        spellcheck_action.setChecked(profile.isSpellCheckEnabled())
        spellcheck_action.toggled.connect(self._toggle_spellcheck)
        menu.addAction(spellcheck_action)

        language_action = QAction(_("Languages…"), self)
        language_action.setEnabled(profile.isSpellCheckEnabled())
        language_action.setToolTip(
            _("Choose the languages used by the spell checker."))
        language_action.triggered.connect(self._open_spellcheck_language_picker)
        menu.addAction(language_action)

    def _toggle_spellcheck(self, toggled):
        """Ativa/desativa a correção ortográfica."""
        print("Correção ortográfica:", toggled)
        SettingsManager.set("system/spellCheckers", toggled)
        QApplication.instance().getWindow().browser.update_spellcheck()

    def _open_spellcheck_language_picker(self):
        open_spellcheck_language_picker(
            self,
            on_applied=lambda: QApplication.instance()
            .getWindow().browser.update_spellcheck(),
        )

    def _on_title_changed(self, title):
        """Manipula mudanças no título da página."""
        with probe.scope("title_callback", self):
            num = ''.join(filter(str.isdigit, title))
            qtd = int(num) if num else 0
            self.update_button_signal.emit(self.page_index, qtd)

    def _on_load_finished(self, success):
        probe.technical("page", "load-ok" if success else "load-failed")
        with probe.scope("load_callback", self):
            if self._shutting_down or not self.user.enable or not self.whatsapp_page:
                return
            if not success:
                print("You are not connected to the Internet.")
                self._reload_timer.start(5000)

    def event(self, event):
        """Intercept native gesture events to optionally disable pinch-to-zoom.
        Handles the rare case where QWebEngineView itself receives the event."""
        native_gesture_type = getattr(QEvent.Type, "NativeGesture", None)
        if native_gesture_type is not None and event.type() == native_gesture_type:
            if _EVENT_MODE == "consume-native-gestures":
                if probe.enabled:
                    probe.record("gesture_consumed", self)
                return True
            if (SettingsManager.get("web/disable_pinch", False) and
                    hasattr(event, 'gestureType') and
                    event.gestureType() == Qt.NativeGestureType.ZoomNativeGesture):
                return True  # Consume the event without zooming
        if probe.enabled:
            return probe.dispatch_event(self, event, super().event)
        return super().event(event)

    @staticmethod
    def _plain_text_paste_script(text):
        """Insert text into the editor that owns the current DOM selection."""
        payload = json.dumps(text)
        return f"""
(() => {{
    const text = {payload};
    const active = document.activeElement;
    const selection = window.getSelection();

    const editableAncestor = (node) => {{
        let element = node;
        if (element && element.nodeType !== Node.ELEMENT_NODE) {{
            element = element.parentElement;
        }}
        while (element && element !== document.documentElement) {{
            if (element.isContentEditable) return element;
            element = element.parentElement;
        }}
        return null;
    }};

    const tag = active ? active.tagName : "";
    const inputType = String((active && active.type) || "text").toLowerCase();
    const textInput = active && (
        tag === "TEXTAREA"
        || (
            tag === "INPUT"
            && !["button", "checkbox", "file", "hidden", "image", "radio",
                 "reset", "submit"].includes(inputType)
        )
    );

    if (textInput) {{
        try {{
            active.focus({{preventScroll: true}});
        }} catch (_error) {{
            active.focus();
        }}
        const start = active.selectionStart ?? active.value.length;
        const end = active.selectionEnd ?? start;
        active.setRangeText(text, start, end, "end");
        active.dispatchEvent(new InputEvent("input", {{
            bubbles: true,
            inputType: "insertText",
            data: text,
        }}));
        return true;
    }}

    const editor = (
        (active && active.isContentEditable ? active : null)
        || editableAncestor(selection && selection.anchorNode)
        || editableAncestor(selection && selection.focusNode)
    );
    if (!editor) return false;

    let range = null;
    if (selection && selection.rangeCount > 0) {{
        const candidate = selection.getRangeAt(0).cloneRange();
        const container = candidate.commonAncestorContainer;
        const containerElement = (
            container.nodeType === Node.ELEMENT_NODE
                ? container
                : container.parentElement
        );
        if (
            containerElement
            && (containerElement === editor || editor.contains(containerElement))
        ) {{
            range = candidate;
        }}
    }}

    try {{
        editor.focus({{preventScroll: true}});
    }} catch (_error) {{
        editor.focus();
    }}

    if (!selection) return false;
    selection.removeAllRanges();
    if (!range) {{
        range = document.createRange();
        range.selectNodeContents(editor);
        range.collapse(false);
    }}
    selection.addRange(range);

    // WhatsApp's composer uses a controlled (Lexical) editor. Dispatch a
    // plain-text paste to its own handler first, so its internal state
    // receives true paragraph breaks. A synthetic paste has no browser
    // default action, so only count it as handled if a listener cancels it.
    try {{
        if (editor.hasAttribute("data-lexical-editor")) {{
            const pasteData = new DataTransfer();
            pasteData.setData("text/plain", text);
            const pasteEvent = new ClipboardEvent("paste", {{
                clipboardData: pasteData, bubbles: true, cancelable: true,
            }});
            editor.dispatchEvent(pasteEvent);
            if (pasteEvent.defaultPrevented) return true;
        }}
    }} catch (_error) {{
        // Older Chromium builds fall back to DOM insertion.
    }}

    try {{
        // WhatsApp may flatten a single insertText event containing LF.
        // Separate insertLineBreak commands preserve empty spreadsheet rows.
        if (text.includes("\\n")) {{
            const lines = text.split("\\n");
            let inserted = false;
            for (let index = 0; index < lines.length; index++) {{
                if (index > 0) {{
                    if (!document.execCommand("insertLineBreak", false, null)) {{
                        return inserted;
                    }}
                    inserted = true;
                }}
                if (lines[index]) {{
                    if (!document.execCommand("insertText", false, lines[index])) {{
                        return inserted;
                    }}
                    inserted = true;
                }}
            }}
            return true;
        }}
        if (document.execCommand("insertText", false, text)) {{
            return true;
        }}
    }} catch (_error) {{
        // Fall back to direct range insertion below.
    }}

    range = selection.getRangeAt(0);
    range.deleteContents();
    const node = document.createTextNode(text);
    range.insertNode(node);
    range.setStartAfter(node);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);

    editor.dispatchEvent(new InputEvent("input", {{
        bubbles: true,
        inputType: "insertText",
        data: text,
    }}));
    return true;
}})();
"""

    @staticmethod
    def _finish_plain_text_paste(page, inserted):
        """Use Chromium's native plain-paste action if DOM insertion failed."""
        if bool(inserted):
            return
        try:
            page.triggerAction(QWebEnginePage.WebAction.PasteAndMatchStyle)
        except RuntimeError:
            pass

    @staticmethod
    def _normalize_plain_text_paste(text):
        """Preserve sheet rows, including blank rows, across line endings."""
        return text.replace("\r\n", "\n").replace("\r", "\n").replace("\u2029", "\n")

    def paste_as_plain_text(self):
        """Paste only clipboard text without changing normal Ctrl+V behavior."""
        probe.technical("clipboard", "plain-text-paste")
        clipboard = QApplication.clipboard()
        text = clipboard.text() if clipboard is not None else ""
        text = self._normalize_plain_text_paste(text)
        if clipboard is not None and hasattr(clipboard, "mimeData"):
            mime = clipboard.mimeData()
            probe.clipboard_formats(mime)
            if mime and mime.hasHtml():
                # LibreOffice also publishes an HTML table. Unlike Qt's
                # flattened text, it explicitly represents empty TR/TD cells.
                table_text = calc_table_as_plain_text(mime.html())
                if table_text is not None:
                    text = self._normalize_plain_text_paste(table_text)

        # Consume this shortcut even if the clipboard also exposes HTML/image.
        # Empty text must never fall through to an image representation.
        if not text:
            return True

        try:
            page = self.page()
            page.runJavaScript(
                self._plain_text_paste_script(text),
                lambda inserted, target=page: (
                    self._finish_plain_text_paste(target, inserted)
                ),
            )
        except RuntimeError:
            return False
        return True

    def eventFilter(self, watched, event):
        """Handle WebEngine child events that do not reach WebView directly."""
        # This filter sees every application event once per account; check the
        # cheap event type before walking widget ancestry.
        event_type = event.type()
        if probe.enabled and watched is self:
            probe.record("filter_event", self, event_type=event_type)
        is_escape = (
            event_type == QEvent.Type.KeyPress
            and event.key() == Qt.Key.Key_Escape
        )
        is_native_gesture = event_type == QEvent.Type.NativeGesture
        if not is_escape and not is_native_gesture:
            return False

        targets_web_content = watched is self or (
            isinstance(watched, QWidget) and self.isAncestorOf(watched)
        )

        if (
            is_escape
            and targets_web_content
            and (watched is self or watched.window() is self.window())
        ):
            self.clear_download_directory()

        if is_native_gesture and targets_web_content:
            if probe.enabled:
                probe.watch(watched, "render-widget", self)
                gesture = event.gestureType() if hasattr(event, "gestureType") else None
                probe.record("gesture_filtered", watched, owner=probe.key(self),
                             gesture_type=gesture)
            if _EVENT_MODE == "consume-native-gestures":
                return True
        if is_native_gesture:
            if SettingsManager.get("web/disable_pinch", False):
                try:
                    if event.gestureType() == Qt.NativeGestureType.ZoomNativeGesture:
                        if targets_web_content:
                            return True  # Consume — block the zoom
                except AttributeError:
                    pass
        return False  # Pass all other events through

    def set_zoom_factor_page(self, factor=None):
        """Define ou ajusta o fator de zoom da página."""
        new_zoom = 1.0 if factor is None else self.zoomFactor() + factor
        new_zoom = max(MIN_ZOOM_FACTOR, min(new_zoom, MAX_ZOOM_FACTOR))
        applied_zoom = apply_zoom_factor(self, new_zoom)
        if self.user.zoomFactor != applied_zoom:
            self.user.zoomFactor = applied_zoom

    def load_page(self):
        """Carrega a página do WhatsApp."""
        with probe.scope("load_page", self):
            if self._shutting_down:
                return

            if self.user.enable and self.whatsapp_page:
                probe.record("set_page", self, owner=probe.key(self.whatsapp_page) if probe.enabled else None)
                self.setPage(self.whatsapp_page)
                self.load(QUrl(__whatsapp_url__))
                applied_zoom = apply_zoom_factor(self, self.user.zoomFactor)
                if self.user.zoomFactor != applied_zoom:
                    self.user.zoomFactor = applied_zoom

    def set_audio_muted(self, muted: bool) -> None:
        """Apply the global audio state to this account and its popups."""
        muted = bool(muted)
        if self.whatsapp_page is not None:
            try:
                self.whatsapp_page.setAudioMuted(muted)
            except RuntimeError:
                pass
        for popup in tuple(self._popup_windows):
            page = getattr(popup, "popup_page", None)
            if page is not None:
                try:
                    page.setAudioMuted(muted)
                except RuntimeError:
                    pass

    def apply_custom_css(self):
        if self.user.enable and self.whatsapp_page:
            self.whatsapp_page.apply_custom_css()

    def clear_download_directory(self):
        """Discard the account-local Save As suggestion."""
        self.last_download_directory = None

    def close_conversation(self):
        """Simula o pressionamento da tecla 'Escape' na página."""
        self.clear_download_directory()
        if self.user.enable and self.whatsapp_page:
            self.whatsapp_page.close_conversation()

    def apply_theme(self, current_theme, current_color_scheme) -> None:
        if self.whatsapp_page is None:
            return

        self.whatsapp_page.apply_theme(current_theme, current_color_scheme)

    def open_internal_popup(self, page):
        """Promote a routed page to an independent authenticated window."""
        if self._shutting_down:
            return None

        page.setAudioMuted(SystemSettings().audio_muted)
        popup = InternalWebPopup(page, self._on_popup_closed)
        popup.page_index = self.page_index
        self._popup_windows.add(popup)
        popup.show()
        popup.raise_()
        popup.activateWindow()
        return popup

    def _on_popup_closed(self, popup):
        self._popup_windows.discard(popup)

    def close_popup_page(self, page):
        """Close the registered window that owns a redirected popup page."""
        for popup in tuple(self._popup_windows):
            if popup.popup_page is page:
                popup.close_from_host()
                return True
        return False

    def _close_internal_popups(self):
        for popup in tuple(self._popup_windows):
            popup.close_from_host()
        self._popup_windows.clear()

    @staticmethod
    def profile_paths(user_id) -> tuple[str, str]:
        """Resolve o cache e o armazenamento de um perfil sem abri-lo."""
        probe = QWebEngineProfile(str(user_id))
        paths = (probe.cachePath(), probe.persistentStoragePath())
        probe.deleteLater()
        return paths

    def remove_files(self):
        """Remove os arquivos de cache e armazenamento persistente do perfil."""
        # TODO: refatorar a lógica de limpeza de cache de contas excluídas
        # É mais seguro executar a limpeza em um momento menos crítico (próxima
        # inicialização do aplicativo) do que durante a exclusão do perfil.
        # Isso poderia ser feito, talvez, armazenando self._cache_path e
        # self._storage_path por meio do objeto User.
        cache_path = self._cache_path
        storage_path = self._storage_path

        if not cache_path or not storage_path:
            # Contas desabilitadas desde a inicialização nunca abriram um
            # perfil, então os caminhos ainda não foram capturados.
            cache_path, storage_path = self.profile_paths(self.user.id)

        shutil.rmtree(cache_path, ignore_errors=True)
        shutil.rmtree(storage_path, ignore_errors=True)

        self._cache_path = None
        self._storage_path = None

    @classmethod
    def remove_user_files(cls, user_id):
        """Remove persisted profile data without constructing a WebView."""
        cache_path, storage_path = cls.profile_paths(user_id)
        shutil.rmtree(cache_path, ignore_errors=True)
        shutil.rmtree(storage_path, ignore_errors=True)

    def enable_page(self):
        """Ativa a página, configurando novamente."""
        if self._shutting_down:
            return

        if self.whatsapp_page is None and self.profile is None:
            self._initialize()

        self.setVisible(True)

    def disable_page(self):
        """Permanently tear down this disabled runtime instance."""
        if self._shutting_down:
            return

        self._shutting_down = True
        self._teardown_webengine(clear_cache=True)

    def shutdown(self):
        with probe.scope("shutdown", self):
            if self._shutting_down:
                return

            self._shutting_down = True
            self._teardown_webengine(clear_cache=False)

    def _stop_timers(self):
        for timer in (
                getattr(self, "_reload_timer", None),
                getattr(self, "_render_crash_reload_timer", None),
        ):
            if timer:
                timer.stop()

    def _teardown_webengine(self, clear_cache: bool = False):
        """Destrói objetos Qt associados à WebEngine de forma ordenada."""
        with probe.scope("teardown", self):
            self.clear_download_directory()
            self._stop_timers()
            self._save_zoom_factor()
            self.stop()
            self._close_internal_popups()

            if self._gesture_filter_installed:
                app = QApplication.instance()
                if app:
                    app.removeEventFilter(self)
                self._gesture_filter_installed = False

            page = self.whatsapp_page
            if page:
                try:
                    page.setDevToolsPage(None)
                    probe.record("detach_page", self)
                    self.setPage(None)
                    probe.record("delete_later", page)
                    page.deleteLater()
                except RuntimeError:
                    pass
                finally:
                    self.whatsapp_page = None

            if self._devtools_view:
                try:
                    self._devtools_view.setPage(None)
                    self._devtools_view.close()
                    self._devtools_view.deleteLater()
                except RuntimeError:
                    pass
                finally:
                    self._devtools_view = None
                    self._devtools_page = None

            if self.profile:
                try:
                    crash_handler.unregister_profile(self.profile)
                    if clear_cache:
                        self.profile.clearHttpCache()
                    probe.record("delete_later", self.profile)
                    self.profile.deleteLater()
                except RuntimeError:
                    pass
                finally:
                    self.profile = None

            probe.record("hide_after_detach", self)
            self.setVisible(False)

    def open_devtools(self):
        """Abre a janela de DevTools para a página atual."""
        current_page = self.page()
        if not self.user.enable or not current_page:
            return

        if self._devtools_view is None:
            self._devtools_view = QWebEngineView()
            probe.watch(self._devtools_view, "devtools-view", self)

            account_name = self.user.name if self.user.name else _("Account")
            self._devtools_view.setWindowTitle(
                _("DevTools - {}").format(account_name)
            )
            self._devtools_view.resize(1100, 700)

        if self._devtools_page is None:
            self._devtools_page = QWebEnginePage(
                self.profile, self._devtools_view)
            probe.watch(self._devtools_page, "devtools-page", self._devtools_view)

        current_page.setDevToolsPage(self._devtools_page)
        self._devtools_view.setPage(self._devtools_page)
        self._devtools_view.show()
        self._devtools_view.raise_()
        self._devtools_view.activateWindow()


# Import-time, process-only A/B: inherit Qt dispatch without a Python override.
# The application-level filter remains installed and preferences are untouched.
if _EVENT_MODE == "no-event-override":
    del WebView.event
