"""Configuration and persistence infrastructure."""
