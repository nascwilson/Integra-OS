"""Controller for the appearance settings page."""

from gettext import gettext as _

from PyQt6.QtWidgets import QApplication

from zapzap.features.settings.pages.appearance.model import AppearanceSettingsModel
from zapzap.assets.icons.tray_icon import TrayIcon
from zapzap.core.theme.theme_manager import ThemeManager
from zapzap.features.settings.pages.appearance.view import AppearanceSettingsView
from zapzap.ui.components import SettingsRestartBar


class AppearanceSettingsController(AppearanceSettingsView):
    """Coordinates appearance settings state and actions for the view."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.model = AppearanceSettingsModel()
        self._load_settings()
        self._restart_baseline = {
            "scale": self.model.scale,
            "csr_enabled": self.model.csr_enabled,
        }
        self._connect_signals()

    def _load_settings(self):
        self.browser_sidebar.setChecked(self.model.browser_sidebar_visible)
        self.mainwindow_menu.setChecked(self.model.menubar_visible)
        self.resizable_chat_list.setChecked(
            self.model.resizable_chat_list_enabled
        )
        self.scaleComboBox.setCurrentText(f"{self.model.scale} %")
        self.tray_groupBox.checkbox.setChecked(self.model.tray_icon_enabled)
        self.notificationCounter.setChecked(
            self.model.notification_counter_enabled)
        self.gridColsComboBox.setCurrentText(str(self.model.grid_columns))

        self.floating_monitoring_panel_enabled.setChecked(
            self.model.floating_monitoring_panel_enabled
        )
        self.floating_mode.setCurrentIndex(
            self.floating_mode.findData(self.model.floating_panel_mode)
        )
        self.floating_on_top_row.checkbox.setChecked(self.model.floating_panel_on_top)
        self.floating_remember_row.checkbox.setChecked(self.model.floating_panel_remember_position)
        self.floating_lock_row.checkbox.setChecked(self.model.floating_panel_lock_position)
        self.integrated_account_selector_enabled.setChecked(
            self.model.integrated_account_selector_enabled
        )

        self.csr_groupBox.checkbox.setChecked(self.model.csr_enabled)
        self._load_csr_button_themes()
        self.csr_show_minimize_checkBox.setChecked(
            self.model.csr_show_minimize_button
        )
        self.csr_show_maximize_checkBox.setChecked(
            self.model.csr_show_maximize_button
        )
        direction_index = self.csr_direction_comboBox.findData(
            self.model.csr_buttons_direction
        )
        if direction_index >= 0:
            self.csr_direction_comboBox.setCurrentIndex(direction_index)

        self._set_selected_radio(
            self.model.theme,
            {
                ThemeManager.Type.Auto.value: self.theme_auto_radioButton,
                ThemeManager.Type.Light.value: self.theme_light_radioButton,
                ThemeManager.Type.Dark.value: self.theme_dark_radioButton,
            },
        )
        self._set_selected_radio(
            self.model.tray_theme,
            {
                TrayIcon.Type.Default.value: self.tray_default_radioButton,
                TrayIcon.Type.SLight.value: self.tray_slight_radioButton,
                TrayIcon.Type.SDark.value: self.tray_sdark_radioButton,
            },
        )
        self._sync_dependent_controls()

    def _load_csr_button_themes(self):
        self.csr_theme_comboBox.blockSignals(True)
        self.csr_theme_comboBox.clear()
        theme_labels = {
            "default": _("Default"),
            "adwaita": _("Adwaita"),
            "plasma": _("Plasma"),
            "ios": _("iOS"),
            "windows": _("Windows"),
        }
        for theme in self.model.available_csr_button_themes():
            self.csr_theme_comboBox.addItem(theme_labels.get(theme, theme), theme)

        theme_index = self.csr_theme_comboBox.findData(
            self.model.csr_button_theme
        )
        self.csr_theme_comboBox.setCurrentIndex(
            theme_index if theme_index >= 0 else 0)
        self.csr_theme_comboBox.blockSignals(False)

    def _connect_signals(self):
        self.browser_sidebar.clicked.connect(self._handle_sidebar)
        self.mainwindow_menu.clicked.connect(self._handle_menubar)
        self.resizable_chat_list.toggled.connect(
            self._handle_resizable_chat_list_enabled
        )
        self.compact_chat_list_row.button.clicked.connect(self._compact_chat_list)
        self.scaleComboBox.currentTextChanged.connect(self._handle_scale)
        self.tray_groupBox.checkbox.toggled.connect(self._handle_tray_enabled)
        self.notificationCounter.clicked.connect(
            self._handle_notification_counter)
        self.gridColsComboBox.currentTextChanged.connect(
            self._handle_grid_cols)
        self.floating_monitoring_panel_enabled.toggled.connect(
            self._handle_floating_monitoring_panel_enabled
        )
        self.floating_mode.currentIndexChanged.connect(self._handle_floating_mode)
        self.floating_on_top_row.checkbox.toggled.connect(
            lambda value: self._handle_floating_option("on_top", value)
        )
        self.floating_remember_row.checkbox.toggled.connect(
            lambda value: self._handle_floating_option("remember_position", value)
        )
        self.floating_lock_row.checkbox.toggled.connect(
            lambda value: self._handle_floating_option("lock_position", value)
        )
        self.floating_show_row.button.clicked.connect(
            lambda: QApplication.instance().getWindow().show_floating_panel()
        )
        self.floating_reset_row.button.clicked.connect(
            lambda: QApplication.instance().getWindow().reset_floating_panel_position()
        )
        self.integrated_account_selector_enabled.toggled.connect(
            self._handle_integrated_account_selector_enabled
        )
        self.tray_default_radioButton.toggled.connect(self._handle_tray_mode)
        self.tray_slight_radioButton.toggled.connect(self._handle_tray_mode)
        self.tray_sdark_radioButton.toggled.connect(self._handle_tray_mode)
        self.theme_auto_radioButton.toggled.connect(self._handle_theme_mode)
        self.theme_light_radioButton.toggled.connect(self._handle_theme_mode)
        self.theme_dark_radioButton.toggled.connect(self._handle_theme_mode)
        self.csr_groupBox.checkbox.toggled.connect(self._handle_csr_enabled)
        self.csr_theme_comboBox.currentIndexChanged.connect(
            self._handle_csr_theme)
        self.csr_show_minimize_checkBox.toggled.connect(
            self._handle_csr_show_minimize
        )
        self.csr_show_maximize_checkBox.toggled.connect(
            self._handle_csr_show_maximize
        )
        self.csr_direction_comboBox.currentIndexChanged.connect(
            self._handle_csr_direction
        )
        self.restart_bar.restart_requested.connect(self._restart_required)

    @staticmethod
    def _set_selected_radio(selected_value, radio_map):
        radio_button = radio_map.get(selected_value)
        if radio_button:
            radio_button.setChecked(True)

    @staticmethod
    def _get_selected_radio(radio_map):
        for radio_button, value in radio_map.items():
            if radio_button.isChecked():
                return value
        return None

    def _handle_sidebar(self):
        enabled = self.browser_sidebar.isChecked()
        QApplication.instance().getWindow().set_sidebar_visible(enabled)

    def _handle_menubar(self):
        self.model.menubar_visible = self.mainwindow_menu.isChecked()
        QApplication.instance().getWindow().settings_menubar()

    def _handle_resizable_chat_list_enabled(self, enabled):
        self.model.resizable_chat_list_enabled = enabled
        window = QApplication.instance().getWindow()
        window.browser.set_resizable_chat_list_enabled(enabled)

    def _compact_chat_list(self):
        # The action uses the existing resize preference and per-account width.
        self.resizable_chat_list.setChecked(True)
        QApplication.instance().getWindow().browser.compact_chat_list()

    def _handle_scale(self, text):
        digits = "".join(filter(str.isdigit, text))
        if digits:
            self.model.scale = int(digits)
            self._update_restart_requirement()

    def _handle_tray_enabled(self, enabled):
        self.model.tray_icon_enabled = enabled
        self.model.apply_tray_icon_enabled(enabled)
        self.tray_options_group.setEnabled(enabled)

    def _handle_notification_counter(self):
        self.model.notification_counter_enabled = self.notificationCounter.isChecked()
        self.model.refresh_tray()

    def _handle_grid_cols(self, text):
        if text:
            self.model.grid_columns = int(text)

    def _handle_floating_monitoring_panel_enabled(self, enabled):
        self.floating_options_group.setEnabled(enabled)
        self.floating_options_group.setVisible(enabled)
        self.model.floating_monitoring_panel_enabled = enabled
        QApplication.instance().getWindow().set_floating_monitoring_panel_enabled(
            enabled, persist=False
        )

    def _handle_floating_mode(self, _index):
        self.model.floating_panel_mode = self.floating_mode.currentData()
        QApplication.instance().getWindow().apply_floating_panel_options(reset_visibility=True)

    def _handle_floating_option(self, name, value):
        setattr(self.model, f"floating_panel_{name}", value)
        QApplication.instance().getWindow().apply_floating_panel_options()

    def _handle_integrated_account_selector_enabled(self, enabled):
        self.model.integrated_account_selector_enabled = enabled
        window = QApplication.instance().getWindow()
        window.browser.set_integrated_account_selector_enabled(enabled)

    def _handle_tray_mode(self):
        selected_tray_mode = self._get_selected_radio(
            {
                self.tray_default_radioButton: TrayIcon.Type.Default,
                self.tray_slight_radioButton: TrayIcon.Type.SLight,
                self.tray_sdark_radioButton: TrayIcon.Type.SDark,
            }
        )
        if selected_tray_mode:
            self.model.tray_theme = selected_tray_mode.value
            self.model.apply_tray_theme(selected_tray_mode)

    def _handle_theme_mode(self):
        selected_theme_mode = self._get_selected_radio(
            {
                self.theme_auto_radioButton: ThemeManager.Type.Auto,
                self.theme_light_radioButton: ThemeManager.Type.Light,
                self.theme_dark_radioButton: ThemeManager.Type.Dark,
            }
        )
        if selected_theme_mode:
            self.model.theme = selected_theme_mode.value
            self.model.apply_theme(selected_theme_mode)

    def _refresh_csr_buttons(self):
        window = QApplication.instance().getWindow()
        if getattr(window, "is_csr_wrapper", False):
            window.refresh_csr_button_preferences()

    def _handle_csr_enabled(self, enabled):
        self.model.csr_enabled = enabled
        self.csr_options_group.setEnabled(enabled)
        self._update_restart_requirement()

    def _sync_dependent_controls(self):
        self.floating_options_group.setVisible(
            self.floating_monitoring_panel_enabled.isChecked()
        )
        self.floating_options_group.setEnabled(
            self.floating_monitoring_panel_enabled.isChecked()
        )
        self.tray_options_group.setEnabled(
            self.tray_groupBox.checkbox.isChecked()
        )
        self.csr_options_group.setEnabled(
            self.csr_groupBox.checkbox.isChecked()
        )

    def _handle_csr_theme(self, _index):
        theme = self.csr_theme_comboBox.currentData()
        if theme:
            self.model.csr_button_theme = theme
            self._refresh_csr_buttons()

    def _handle_csr_show_minimize(self, enabled):
        self.model.csr_show_minimize_button = enabled
        self._refresh_csr_buttons()

    def _handle_csr_show_maximize(self, enabled):
        self.model.csr_show_maximize_button = enabled
        self._refresh_csr_buttons()

    def _handle_csr_direction(self, _index):
        direction = self.csr_direction_comboBox.currentData()
        if direction:
            self.model.csr_buttons_direction = direction
            self._refresh_csr_buttons()

    def _update_restart_requirement(self):
        if self.model.scale != self._restart_baseline["scale"]:
            self.set_restart_required(SettingsRestartBar.APPLICATION)
        elif self.model.csr_enabled != self._restart_baseline["csr_enabled"]:
            self.set_restart_required(SettingsRestartBar.INTERFACE)
        else:
            self.set_restart_required()

    def _restart_required(self, restart_kind):
        app = QApplication.instance()
        if restart_kind == SettingsRestartBar.APPLICATION:
            app.restartApplication()
        else:
            app.restartInterface()
