"""Browser feature."""
