from __future__ import annotations

from zapzap.core.diagnostics.webengine_probe import probe

from typing import TYPE_CHECKING

from pathlib import Path
from gettext import gettext as _
import logging

from PyQt6.QtWebEngineCore import QWebEngineNotification

from zapzap.core.config.settings_manager import SettingsManager
from zapzap import __appname__

from zapzap.features.notifications.portal_notification_backend import (
    PortalNotificationBackend
)
from zapzap.features.notifications.freedesktop_notification_backend import (
    FreedesktopNotificationBackend
)

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from zapzap.features.browser.web.web_view import WebView


def is_flatpak() -> bool:
    return Path("/.flatpak-info").exists()


class NotificationService:
    """
    Fachada única para notificações.

    Decide o backend (Portal / Freedesktop / None)
    e delega completamente a ele.
    """

    _backend = None

    def __init__(self):
        if NotificationService._backend is None:
            NotificationService._backend = self._select_backend()

        self.backend = NotificationService._backend

    # ------------------------------------------------------------------
    # Backend selection
    # ------------------------------------------------------------------
    def _select_backend(self):
        from zapzap.core.platform import IS_WINDOWS, IS_MAC
        if IS_WINDOWS:
            from zapzap.features.notifications.windows_notification_backend import (
                WindowsNotificationBackend,
            )
            return WindowsNotificationBackend()

        if IS_MAC:
            from zapzap.features.notifications.macos_notification_backend import (
                MacosNotificationBackend,
            )
            return MacosNotificationBackend()

        if is_flatpak():
            return PortalNotificationBackend()

        backend = FreedesktopNotificationBackend()
        if backend.available():
            return backend

        logger.warning(
            "No notification backend is available; "
            "desktop notifications are disabled for this session."
        )
        return None

    @classmethod
    def shutdown(cls):
        """Withdraw active notifications before the application exits."""
        backend = cls._backend
        if backend is None:
            return

        close_all = getattr(backend, "close_all", None)
        if close_all is not None:
            close_all()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def notify(
        self,
        page: WebView,
        notification: QWebEngineNotification
    ):
        # =================================================
        # 1. Regras globais (app / usuário)
        # =================================================
        if not SettingsManager.get("notification/app", True):
            probe.technical("notification", "global-disabled")
            return

        if not SettingsManager.get(
            f"{page.user.id}/notification", True
        ):
            probe.technical("notification", "account-disabled")
            return

        if not self.backend:
            probe.technical("notification", "backend-unavailable")
            return

        # =================================================
        # 2. Conteúdo (decisão global)
        # =================================================
        title = (
            notification.title()
            if SettingsManager.get("notification/show_name", True)
            else __appname__
        )

        message = (
            notification.message()
            if SettingsManager.get("notification/show_msg", True)
            else _("New message...")
        )

        # =================================================
        # 3. Delegação total ao backend
        # =================================================
        try:
            self.backend.notify(
                page=page,
                notification=notification,
                title=title,
                message=message,
            )
            probe.technical("notification", "forwarded")
        except Exception:
            probe.technical("notification", "forward-failed")
            # Notification failures must never crash the app.
            logger.warning(
                "Notification backend failed; dropping notification",
                exc_info=True,
            )
