"""View for the Performance experimental settings page."""

from gettext import gettext as _

from zapzap.ui.primitives import RadioButton
from zapzap.ui.components import SettingsActionRow
from zapzap.ui.components import SettingsCard
from zapzap.ui.components import SettingsInfoBox
from zapzap.ui.components import SettingsPage
from zapzap.ui.components import SettingsRadioGroup
from zapzap.ui.components import SettingsSection
from zapzap.ui.components import SettingsSelectRow
from zapzap.ui.components import SettingsSwitchRow


class PerformanceExperimentalSettingsView(SettingsPage):
    """Composable performance settings view without persistence logic."""

    def __init__(self, parent=None):
        super().__init__(
            _("Performance experimental"),
            _("Tune cache, GPU, processes, and advanced behavior."),
            parent,
        )
        self._setup_ui()
        self.add_stretch()

    def _setup_ui(self):
        self._setup_warning_section()
        self._setup_rendering_profile_section()
        self._setup_cache_section()
        self._setup_gpu_section()
        self._setup_process_section()
        self._setup_js_section()
        self._setup_web_section()
        self._setup_restore_section()

    def _setup_warning_section(self):
        section = SettingsSection(
            _("Advanced warning"),
            _("These options may require restart and can affect stability."),
        )
        card = SettingsCard()
        card.add_row(
            SettingsInfoBox(
                _(
                    "Change these settings only if you understand the trade-offs. "
                    "Restart ZapZap after changing rendering, process, or JavaScript memory options."
                ),
                "warning",
            )
        )
        section.add_card(card)
        self.add_section(section)

    def _setup_rendering_profile_section(self):
        section = SettingsSection(
            _("Rendering profile"),
            _(
                "Choose a predefined rendering configuration or customize "
                "individual options."
            ),
        )
        card = SettingsCard()
        self.rendering_default_radio = RadioButton(_("Default"))
        self.rendering_compatibility_radio = RadioButton(_("Compatibility"))
        self.rendering_manual_radio = RadioButton(_("Manual"))
        descriptions = (
            _("Recommended settings with hardware acceleration enabled."),
            _(
                "Improves stability on systems with video, flickering or GPU "
                "rendering issues."
            ),
            _("Use custom GPU and rendering options."),
        )
        for radio, description in zip(
            (
                self.rendering_default_radio,
                self.rendering_compatibility_radio,
                self.rendering_manual_radio,
            ),
            descriptions,
        ):
            radio.setAccessibleDescription(description)
            radio.setToolTip(description)
        self.rendering_profile_group = SettingsRadioGroup(
            self.rendering_default_radio,
            self.rendering_compatibility_radio,
            self.rendering_manual_radio,
        )
        card.add_row(self.rendering_profile_group)
        section.add_card(card)
        self.add_section(section)

    def _setup_cache_section(self):
        section = SettingsSection(
            _("Cache"),
            _("Control HTTP cache and persistent cookies."),
        )
        card = SettingsCard()
        self.cache_type_row = SettingsSelectRow(
            _("Cache type"),
            _("Defines where the HTTP cache is stored."),
            [""]
        )
        self.cache_size_max_row = SettingsSelectRow(
            _("Maximum cache size"),
            _("0 MiB uses Chromium's automatic cache management."),
            [""]
        )
        self.persistent_cookies_row = SettingsSwitchRow(
            _("Persistent cookies"),
            _("Keeps cookies between restarts."),
        )
        self.cache_type = self.cache_type_row.combo
        self.cache_size_max = self.cache_size_max_row.combo
        self.persistent_cookies = self.persistent_cookies_row.checkbox
        card.add_group(
            self.cache_type_row,
            (self.cache_size_max_row,),
        )
        card.add_row(self.persistent_cookies_row)
        section.add_card(card)
        self.add_section(section)

    def _setup_gpu_section(self):
        section = SettingsSection(
            _("GPU and rendering"),
            _("Rendering options for problematic drivers or hardware."),
        )
        card = SettingsCard()
        self.in_process_gpu_row = SettingsSwitchRow(
            _("In-process GPU"),
            _("May reduce memory usage, but can cause instability."),
        )
        self.disable_gpu_row = SettingsSwitchRow(
            _("Disable GPU"),
            _("Recommended only for old GPUs or problematic drivers."),
        )
        self.auto_gpu_workaround_row = SettingsSwitchRow(
            _("Automatic multi-GPU workaround"),
            _(
                "Honors DRI_PRIME or adjusts GPU compositing for a headless secondary GPU."
            ),
        )
        self.disable_gpu_vsync_row = SettingsSwitchRow(
            _("Disable GPU VSync"),
            _("May reduce latency, but can increase tearing."),
        )
        self.software_rendering_row = SettingsSwitchRow(
            _("Force software rendering"),
            _("Use only for graphical issues."),
        )
        self.disable_gpu_memory_buffer_video_frames_row = SettingsSwitchRow(
            _("Disable GPU memory buffer for video"),
            _(
                "Avoid GPU-backed video frame buffers. May help with black "
                "screens, flickering and GPU crashes."
            ),
        )
        self.disable_zero_copy_row = SettingsSwitchRow(
            _("Disable zero-copy"),
            _(
                "Disable zero-copy GPU buffer transfers. May improve "
                "compatibility with some graphics drivers."
            ),
        )
        self.software_video_decoding_row = SettingsSwitchRow(
            _("Use software video decoding"),
            _(
                "Disables hardware video decoding to fix videos that appear "
                "white, black, flicker, or cause crashes. This may increase "
                "CPU and battery usage."
            ),
        )
        self.force_gbm_row = SettingsSwitchRow(
            _("Force GBM"),
            _("Known NVIDIA typing lag fix."),
        )
        self.disable_accessibility_row = SettingsSwitchRow(
            _("Disable accessibility bus"),
            _("Known typing lag or CPU spike fix in QtWebEngine."),
        )
        self.in_process_gpu = self.in_process_gpu_row.checkbox
        self.disable_gpu = self.disable_gpu_row.checkbox
        self.auto_gpu_workaround = self.auto_gpu_workaround_row.checkbox
        self.disable_gpu_vsync = self.disable_gpu_vsync_row.checkbox
        self.software_rendering = self.software_rendering_row.checkbox
        self.disable_gpu_memory_buffer_video_frames = (
            self.disable_gpu_memory_buffer_video_frames_row.checkbox
        )
        self.disable_zero_copy = self.disable_zero_copy_row.checkbox
        self.software_video_decoding = self.software_video_decoding_row.checkbox
        self.force_gbm = self.force_gbm_row.checkbox
        self.disable_accessibility = self.disable_accessibility_row.checkbox
        for row in (
            self.in_process_gpu_row,
            self.disable_gpu_row,
            self.auto_gpu_workaround_row,
            self.disable_gpu_vsync_row,
            self.software_rendering_row,
            self.disable_gpu_memory_buffer_video_frames_row,
            self.disable_zero_copy_row,
            self.software_video_decoding_row,
            self.force_gbm_row,
            self.disable_accessibility_row,
        ):
            card.add_row(row)
        section.add_card(card)
        self.add_section(section)

    def _setup_process_section(self):
        section = SettingsSection(
            _("Processes"),
            _("Chromium process model options."),
        )
        card = SettingsCard()
        self.single_process_row = SettingsSwitchRow(
            _("Single process"),
            _("Experimental; reduces memory usage but may cause crashes."),
        )
        self.process_per_site_row = SettingsSwitchRow(
            _("Process per site"),
            _("Safer and more stable, but may increase memory usage."),
        )
        self.single_process = self.single_process_row.checkbox
        self.process_per_site = self.process_per_site_row.checkbox
        card.add_row(self.single_process_row)
        card.add_row(self.process_per_site_row)
        section.add_card(card)
        self.add_section(section)

    def _setup_js_section(self):
        section = SettingsSection(
            _("JavaScript memory"),
            _("V8 memory limit. Restart required."),
        )
        card = SettingsCard()
        self.js_memory_limit_row = SettingsSelectRow(
            _("JavaScript memory limit"),
            _("Automatic is the safest option."),
            [""],
        )
        self.js_predictable_gc_schedule_row = SettingsSwitchRow(
            _("JavaScript GC predictable schedule (experimental)"),
            _("Enables predictable V8 garbage collection and disables GPU."),
        )
        self.js_memory_limit = self.js_memory_limit_row.combo
        self.js_predictable_gc_schedule = self.js_predictable_gc_schedule_row.checkbox
        card.add_row(self.js_memory_limit_row)
        card.add_row(self.js_predictable_gc_schedule_row)
        section.add_card(card)
        self.add_section(section)

    def _setup_web_section(self):
        section = SettingsSection(
            _("Web behavior"),
            _("Behavior options for rendered web content."),
        )
        card = SettingsCard()
        self.scroll_animator_row = SettingsSwitchRow(
            _("Smooth scrolling"),
            _("Disabling may reduce CPU usage."),
        )
        self.background_throttling_row = SettingsSwitchRow(
            _("Background throttling"),
            _("Allows background tabs to reduce resource usage."),
        )
        self.disable_animations_row = SettingsSwitchRow(
            _("Disable animations"),
            _("May improve performance on slower machines."),
        )
        self.disable_pinch_row = SettingsSwitchRow(
            _("Disable pinch-to-zoom"),
            _("Useful if accidental zooming occurs during scrolling."),
        )
        self.ctrl_arrow_visual_navigation_fix_row = SettingsSwitchRow(
            _("Fix Ctrl+Arrow cursor movement"),
            _(
                "Use visual word navigation in editable fields to fix RTL text cursor movement."
            ),
        )
        self.scroll_animator = self.scroll_animator_row.checkbox
        self.background_throttling = self.background_throttling_row.checkbox
        self.disable_animations = self.disable_animations_row.checkbox
        self.disable_pinch = self.disable_pinch_row.checkbox
        self.ctrl_arrow_visual_navigation_fix = (
            self.ctrl_arrow_visual_navigation_fix_row.checkbox
        )
        for row in (
            self.scroll_animator_row,
            self.background_throttling_row,
            self.disable_animations_row,
            self.disable_pinch_row,
            self.ctrl_arrow_visual_navigation_fix_row,
        ):
            card.add_row(row)
        section.add_card(card)
        self.add_section(section)

    def _setup_restore_section(self):
        section = SettingsSection(
            _("Restore defaults"),
            _("Return performance settings to safe defaults."),
        )
        card = SettingsCard()
        restore_row = SettingsActionRow(
            _("Restore performance defaults"),
            _("Restores all performance settings to safe default values."),
            _("Restore"),
        )
        self.btn_restore = restore_row.button
        card.add_row(restore_row)
        section.add_card(card)
        self.add_section(section)
