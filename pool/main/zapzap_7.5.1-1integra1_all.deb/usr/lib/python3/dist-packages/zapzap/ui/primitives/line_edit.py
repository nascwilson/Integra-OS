"""ZapZap line edit primitive."""

from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QLineEdit


class LineEdit(QLineEdit):
    """ZapZap line edit styled from the active Qt palette."""

    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self._apply_font()
        self._apply_style()

    def _apply_font(self):
        """Apply line edit typography using Qt's native font handling."""

        font = self.font()
        font.setWeight(QFont.Weight.Normal)
        self.setFont(font)

    def _apply_style(self):
        self.setStyleSheet("""
            QLineEdit {
                min-height: 26px;
                border: 1px solid palette(mid);
                border-radius: 8px;
                padding: 6px 10px;
                background: palette(base);
                color: palette(text);
                selection-background-color: palette(highlight);
                selection-color: palette(highlighted-text);
            }
            QLineEdit:hover {
                border-color: palette(highlight);
                background: palette(alternate-base);
            }
            QLineEdit:focus {
                border: 1px solid palette(highlight);
            }
            QLineEdit[invalid="true"] {
                border: 1px solid palette(bright-text);
            }
            QLineEdit:disabled, QLineEdit:read-only {
                color: palette(placeholder-text);
                background: palette(window);
            }
        """)
