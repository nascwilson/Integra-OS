"""Data access for the general settings page."""

from zapzap.features.startup.autostart_manager import AutostartManager
from zapzap.features.dictionaries.dictionaries_manager import DictionariesManager
from zapzap.features.downloads.download_manager import DownloadManager
from zapzap.core.config.settings.downloads import DownloadSettings
from zapzap.core.config.settings.spellcheck import SpellcheckSettings
from zapzap.core.config.settings.system import SystemSettings
from zapzap.core.environment.setup_manager import SetupManager
from zapzap.core.i18n.translation_manager import TranslationManager


class LanguageDownloadSettingsModel:
    """Facade over services used by the general settings controller."""

    def is_flatpak(self):
        return SetupManager._is_flatpak

    def __init__(self):
        self._spellcheck_settings = SpellcheckSettings()
        self._system_settings = SystemSettings()
        self._download_settings = DownloadSettings()

    @property
    def spellcheck_enabled(self):
        return self._spellcheck_settings.enabled

    @spellcheck_enabled.setter
    def spellcheck_enabled(self, value):
        self._spellcheck_settings.enabled = value

    def get_dictionaries_path(self):
        return DictionariesManager.get_path()

    def list_dictionary_options(self):
        return DictionariesManager.options()

    def get_current_dictionary(self):
        return DictionariesManager.get_current_dict()

    def get_selected_dictionaries(self):
        return DictionariesManager.get_selected_languages()

    def set_dictionary_language(self, language):
        DictionariesManager.set_lang(language)

    def set_dictionary_path(self, path):
        DictionariesManager.set_spell_folder(path)

    def restore_dictionary_path(self):
        return DictionariesManager.restore_default_path()

    @property
    def download_behavior(self):
        return self._download_settings.behavior

    @download_behavior.setter
    def download_behavior(self, value):
        self._download_settings.behavior = value

    @property
    def remember_last_save_as_directory(self):
        return self._download_settings.remember_last_save_as_directory

    @remember_last_save_as_directory.setter
    def remember_last_save_as_directory(self, value):
        self._download_settings.remember_last_save_as_directory = value

    @property
    def pdf_click_behavior(self):
        return self._download_settings.pdf_click_behavior

    @pdf_click_behavior.setter
    def pdf_click_behavior(self, value):
        self._download_settings.pdf_click_behavior = value

    @property
    def auto_open_pdf(self):
        return self._download_settings.auto_open_pdf

    @auto_open_pdf.setter
    def auto_open_pdf(self, value):
        self._download_settings.auto_open_pdf = value

    @property
    def auto_open_images(self):
        return self._download_settings.auto_open_images

    @auto_open_images.setter
    def auto_open_images(self, value):
        self._download_settings.auto_open_images = value

    def clear_multiple_download_permissions(self):
        self._download_settings.clear_multiple_download_permission()

    def get_download_path(self):
        return DownloadManager.get_path()

    def set_download_path(self, path):
        DownloadManager.set_path(path)

    def restore_download_path(self):
        DownloadManager.restore_path()
        return DownloadManager.get_path()

    def open_folder_dialog(self, parent):
        return DownloadManager.open_folder_dialog(parent)

    def set_autostart(self, enabled):
        self._system_settings.start_with_system = enabled
        AutostartManager.create_desktop_file(enabled)

    def list_available_languages(self):
        return TranslationManager.list_available_languages()

    def get_current_language(self):
        return TranslationManager.get_current_language()

    def set_current_language(self, language):
        TranslationManager.set_current_language(language)

    def apply_translation(self):
        TranslationManager.apply()
